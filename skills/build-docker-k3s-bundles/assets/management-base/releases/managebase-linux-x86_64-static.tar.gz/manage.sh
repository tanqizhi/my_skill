#!/bin/sh
set -eu
# Resolve using shell builtins only. Symlink entrypoints are intentionally unsupported.
entry=$0
case "$entry" in
  */*) ;;
  *) entry=$(command -v "$entry") ;;
esac
case "$entry" in */*) ;; *) entry="./$entry" ;; esac
if [ -L "$entry" ]; then
  printf '%s\n' 'Use the real installed manage.sh path, not a symbolic link.' >&2
  exit 2
fi
root=$(CDPATH= cd -P -- "${entry%/*}" && pwd -P)
TERMINFO="$root/runtime/python/share/terminfo"
TERMINFO_DIRS="$TERMINFO"
LC_ALL=C.UTF-8
export TERMINFO TERMINFO_DIRS LC_ALL
exec "$root/runtime/python/bin/python3.12" -I -B -X utf8 "$root/manage.pyz" "$@"
